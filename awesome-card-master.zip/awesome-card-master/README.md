# TzWcc3Challenge
Challenge awesome card with interactive input | [![Netlify Status](https://api.netlify.com/api/v1/badges/328da6b3-4f67-440d-ae18-b7492fdbeb9f/deploy-status)](https://app.netlify.com/sites/awesome-card/deploys)

Inspired from :
[muhammederdem/vue-interactive-paycard](https://github.com/muhammederdem/vue-interactive-paycard)

![https://github.com/julkwel/TzWcc3FrontChallenge/blob/master/assets/scree_shot.png?raw=true](https://github.com/julkwel/TzWcc3FrontChallenge/blob/master/assets/scree_shot.png?raw=true)


*Create cool things, code for fun !!!*
