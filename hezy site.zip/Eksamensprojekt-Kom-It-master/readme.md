_The project is in Danish, though all code (and comments) and descriptions are in English._
--
---
Hello World,
==
This is a school project for my group exam in
Kom/IT (*Communication/Information Technology*).

It is a interactive website - working as a presentation, and it is about `antimatter`, we want to reach young teens from 13-16 years.

Project info
--
* Language: `JavaScript`+`HTML5`
* Enviorment: `p5.js`
* Time elapsed: `15 hour and 25 min`
* Grade: `12 on the 7-step scale`

--------
Hej Verden,
==
Dette er mit og min gruppes eksamensprojekt for Kom/IT C.

Det er en interaktiv hjemmeside - som virker som en præsentation, den handler om `antistof`, vi har prøvet at ramme en målgruppe på 13-16 år.

Projekt information
--
* Sprog: `JavaScript`+`HTML5`
* Enviorment: `p5.js`
* Tid brugt: `15 timer og 25 min`
* Karakter: `12 på 7-trins-skalaen`

---
